
//  Created by Jacob Kaiserman on 4/5/20.





import Foundation
import UIKit
import CoreGraphics
import AudioToolbox
import AVFoundation
class ViewController: UIViewController {
    enum Direction  {
        case left
        case up
        case right
        case down
        case stop
        
    }
//    this defins an array in swift
    var pointList = [UIImageView]()
    var wallList = [UIImageView]()

    @IBOutlet weak var wall: UIImageView!
    
    @IBOutlet weak var scorePoint: UIImageView!
    
    @IBOutlet weak var labelScoreBoard: UILabel!
    enum GhostDirection {
//        path1 - MidR, MidC - StartR, MidC
        case path1
//        path2 - StartR,MidC - StartR, StartC
        case path2
//       path3 - StartR, StartC  - MidR, StartC
        case path3
//        path4 - MidR, StartC - MidR, MidC
        case path4
//        path5 - MidR, MidC - EndR, MidC
        case path5
//        path6 - EndR,MidC - EndR, EndC
        case path6
//       path7 - EndR, EndC  - EndR, MidC
        case path7
//        path8 - EndR, MidC - MidR, MidC
        case path8
        
    }
    var score = 0
    var ghost1PathDirection = GhostDirection.path1
    var ghost2PathDirection = GhostDirection.path1
    var currentDirection = Direction.down
    var ghost1Timer:Timer?
    var ghost2Timer:Timer?
    var ghost1Direction = Direction.up
    var ghost2Direction = Direction.up
    var playerTimer:Timer?
    @IBOutlet weak var wall1: UIImageView!
    @IBOutlet weak var statusLabel: UILabel!
    var gameScreenWidth = CGFloat(0)
    var gameScreenHeight = CGFloat(0)
    var startR = 0
    var startC=40
    var midR =  0 //Int(gameScreenHeight)/2
    var midC = 0 //Int(gameScreenWidth)/2
    var endR = 0
    var endC = 0
    @IBOutlet weak var ghost1: UIImageView!
    
    @IBOutlet weak var ghost2: UIImageView!
    
    
    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var pacman1: UIImageView!
    
        func drawCircle(x:Int, y:Int, radius:Int){
            let circlePath = UIBezierPath(arcCenter: CGPoint(x: x, y: y), radius: CGFloat(radius), startAngle: CGFloat(0),endAngle: CGFloat(Double.pi * 2), clockwise: true)
            let shapeLayer = CAShapeLayer()
            shapeLayer.path = circlePath.cgPath
            shapeLayer.fillColor = UIColor.yellow.cgColor
            shapeLayer.strokeColor = UIColor.yellow.cgColor
            view.layer.addSublayer(shapeLayer)
        }
        func drawLine(start: CGPoint, end:CGPoint) {
           let line = CAShapeLayer()
           let linePath = UIBezierPath()
           linePath.move(to: start)
           linePath.addLine(to: end)
           line.path = linePath.cgPath
           line.strokeColor = UIColor.blue.cgColor
           line.lineWidth = 2
            line.lineCap = .round;
           self.view.layer.addSublayer(line)
       }
    func produceScorePoints(value: Int){

    for i in 0...value{
        let newView = UIImageView(image: scorePoint.image)
//        produce yellow dots
        let x1 = i*100
        newView.frame = CGRect(x: x1, y: 100, width: 15, height: 15)
        pointList.append(newView)
        self.view.addSubview(newView)
    }

      
}
    
// draw canvas wih score points and borders
func initCanvas(){

    drawScorePoints()
    drawMaze()
}

// draw borders
func drawMaze(){
    drawVerticleLines(incr:40 , nol:1 )
    drawVerticleLines(incr:(gameScreenWidth-40) , nol:1 )
    drawHorizontalLines(incr:2 , nol:1)
    drawHorizontalLines(incr:(gameScreenHeight-2) , nol:1)
}

func drawScorePoints(){
    var dif = (midC - startC)/2
    drawVerticalScorePoints(x: CGFloat(startC+10), incr: 44.0, nol: 8)
    drawVerticalScorePoints(x: CGFloat(startC + dif + 3), incr: 44.0, nol: 8)
    drawVerticalScorePoints(x: CGFloat(midC+2), incr: 44.0, nol: 8)
     drawVerticalScorePoints(x: CGFloat(midC+2+dif), incr: 44.0, nol: 8)
    drawVerticalScorePoints(x: CGFloat(endC+5), incr: 44.0, nol: 8)
    drawHorizontalScorePoints(y: CGFloat(startR+15), incr: 50, nol: 16)
    drawHorizontalScorePoints(y: CGFloat(midR+15), incr: 50, nol: 16)
    drawHorizontalScorePoints(y: CGFloat(endR+15), incr: 50, nol: 16)
}
    
    
    
func drawVerticalScorePoints(x: CGFloat, incr: CGFloat , nol:Int){
    let number1 = Int.random(in: 0 ..< nol)
    let number2 = Int.random(in: 0 ..< nol)
    
    var point1 = CGPoint (x:incr , y:0)
               for i in 1...nol {
                 let newView = UIImageView(image: scorePoint.image)
                        let y1 = CGFloat(i)*incr
                        newView.frame = CGRect(x: x, y: y1, width: 15, height: 15)
                        pointList.append(newView)
                        self.view.addSubview(newView)
                
                if(i == number1 || i == number2){
                    let wallView = UIImageView(image: wall.image)
                    wallView.frame = CGRect(x: x-6, y: y1-6, width: 30, height: 30)
                    wallList.append(wallView)
                    self.view.addSubview(wallView)
                }
               }
}

    
func drawHorizontalScorePoints(y: CGFloat, incr: CGFloat , nol:Int){
       var point1 = CGPoint (x:incr , y:0)
       for i in 1...nol {
         let newView = UIImageView(image: scorePoint.image)
                let x1 = CGFloat(i)*incr
                newView.frame = CGRect(x: x1, y: y, width: 15, height: 15)
                pointList.append(newView)
                self.view.addSubview(newView)
       }
}

    
func drawVerticleLines(incr: CGFloat , nol:Int){
        var point1 = CGPoint (x:incr , y:0)
        var point2 = CGPoint (x:incr , y:(gameScreenHeight))
        for i in 1...nol {
        
        drawLine(start:point1, end:point2)
            point1.x = point1.x + incr
            point2.x = point2.x + incr
            
        }
    }
    func drawHorizontalLines(incr: CGFloat , nol:Int){
        var point1 = CGPoint (x:40 , y:incr)
        var point2 = CGPoint (x:(gameScreenWidth-40) , y:incr)
        var yincr=100
        for i in 1...nol {
            drawLine(start:point1, end:point2)
            point1 = CGPoint (x:0 , y:yincr)
            point2 = CGPoint (x:Int(gameScreenWidth) , y:yincr)
            yincr = yincr + 60
            
        }
    }
    func initSettings(){
        
        let screenRect = UIScreen.main.bounds
        let screenWidth = screenRect.size.width
        let screenHeight = screenRect.size.height
        
        gameScreenWidth = screenWidth
        gameScreenHeight = screenHeight
        midR = Int(gameScreenHeight)/2
           midC = Int(gameScreenWidth)/2
        endR = Int(gameScreenHeight)-40
        endC = Int(gameScreenWidth)-60
        let imageWidth = Int(ghost1.frame.width)
        endC = endC - imageWidth
        moveObject(imageObject1:ghost1, x:midC, y:midR)
        ghost1PathDirection = GhostDirection.path1
        ghost2PathDirection = GhostDirection.path1
        moveObject(imageObject1:ghost2, x:midC, y:midR)
    }
        
        

    
 override func viewDidLoad() {
     super.viewDidLoad()
     initSettings()
     initCanvas()
 }

    
// MARK:
    
@IBAction func upButtonClicked(_ sender: Any) {
    if(currentDirection == .stop){
        return
    }
    currentDirection = Direction.up
    AudioServicesPlaySystemSound(1104)
}

@IBAction func downButtonClicked(_ sender: Any) {
    if(currentDirection == .stop){
        return
    }
    currentDirection = Direction.down
     AudioServicesPlaySystemSound(1104)
}

@IBAction func rightButtonClicked(_ sender: Any) {
    if(currentDirection == .stop){
        return
    }
    currentDirection = Direction.right
     AudioServicesPlaySystemSound(1104)
}

@IBAction func leftButtonClicked(_ sender: Any) {
    if(currentDirection == .stop){
        return
    }
    currentDirection = Direction.left
     AudioServicesPlaySystemSound(1104)
}
    
@IBAction func MoveButtonClicked(_ sender: Any) {
    
    playerTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(onPlayerTimerFires), userInfo: nil, repeats: true)
    
    ghost1Timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector:            #selector(onGhost1TimerFires), userInfo: nil, repeats: true)
    ghost2Timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(onGhost2TimerFires), userInfo: nil, repeats: true)
    
//        moveObject(imageObject1:pacman1, x:Int(gameScreenWidth/2), y:Int(gameScreenHeight/2))
moveObject(imageObject1:pacman1, x:Int(gameScreenWidth/2), y:0)
}

@objc func onGhost1TimerFires() {
    
    let ghostY = Int(ghost1.frame.origin.y);
    let ghostX = Int(ghost1.frame.origin.x)
    if(ghost1PathDirection == GhostDirection.path1){
        if(ghostY <= startR){
            ghost1PathDirection = GhostDirection.path2
        }
        else{
            moveObject(imageObject1:ghost1, x:ghostX, y:ghostY-5)
        }
        
    }
    else if(ghost1PathDirection == GhostDirection.path2){
        if(ghostX <= startC){
            ghost1PathDirection = GhostDirection.path3
        }
        else{
            moveObject(imageObject1:ghost1, x:ghostX-5, y:ghostY)
        }
        
    }
    else if(ghost1PathDirection == GhostDirection.path3){
        if(ghostY >= midR){
            ghost1PathDirection = GhostDirection.path4
        }
        else{
            moveObject(imageObject1:ghost1, x:ghostX, y:ghostY+5)
        }
        
    }
    else if(ghost1PathDirection == GhostDirection.path4){
        if(ghostX >= midC){
            ghost1PathDirection = GhostDirection.path5
        }
        else{
            moveObject(imageObject1:ghost1, x:ghostX+5, y:ghostY)
        }
        
    }
    else if(ghost1PathDirection == GhostDirection.path5){
        if(ghostX >= endC){
            ghost1PathDirection = GhostDirection.path6
        }
            
        else{
            moveObject(imageObject1:ghost1, x:ghostX+5, y:ghostY)
        }
        
    }
    else if(ghost1PathDirection == GhostDirection.path6){
        if(ghostY >= endR){
            ghost1PathDirection = GhostDirection.path7
        }
            
        else{
            moveObject(imageObject1:ghost1, x:ghostX, y:ghostY+5)
        }
        
    }
    else if(ghost1PathDirection == GhostDirection.path7){
        if(ghostX <= midC){
            ghost1PathDirection = GhostDirection.path8
        }
            
        else{
            moveObject(imageObject1:ghost1, x:ghostX-5, y:ghostY)
        }
        
    }
    else if(ghost1PathDirection == GhostDirection.path8){
               if(ghostY <= midR){
                   ghost1PathDirection = GhostDirection.path1
//                     moveObject(imageObject1:ghost1, x:midC, y:midR)
               }
                   
               else{
                   moveObject(imageObject1:ghost1, x:ghostX, y:ghostY-5)
               }
               
           }
    
        
        
    }
    
 @objc func onGhost2TimerFires() {

          let ghostY = Int(ghost2.frame.origin.y);
            let ghostX = Int(ghost2.frame.origin.x)
            if(ghost2PathDirection == GhostDirection.path1){
                if(ghostY <= startR){
                    ghost2PathDirection = GhostDirection.path2
                }
                else{
                    moveObject(imageObject1:ghost2, x:ghostX, y:ghostY-5)
                }
                
            }
            else if(ghost2PathDirection == GhostDirection.path2){
                if(ghostX >= endC){
                    ghost2PathDirection = GhostDirection.path3
                }
                else{
                    moveObject(imageObject1:ghost2, x:ghostX+5, y:ghostY)
                }
                
            }
            else if(ghost2PathDirection == GhostDirection.path3){
                if(ghostY >= midR){
                    ghost2PathDirection = GhostDirection.path4
                }
                else{
                    moveObject(imageObject1:ghost2, x:ghostX, y:ghostY+5)
                }
                
            }
            else if(ghost2PathDirection == GhostDirection.path4){
                if(ghostX <= midC){
                    ghost2PathDirection = GhostDirection.path5
                }
                else{
                    moveObject(imageObject1:ghost2, x:ghostX-5, y:ghostY)
                }
                
            }
            else if(ghost2PathDirection == GhostDirection.path5){
                if(ghostX <= startC){
                    ghost2PathDirection = GhostDirection.path6
                }
                    
                else{
                    moveObject(imageObject1:ghost2, x:ghostX-5, y:ghostY)
                }
                
            }
            else if(ghost2PathDirection == GhostDirection.path6){
                if(ghostY >= endR){
                    ghost2PathDirection = GhostDirection.path7
                }
                    
                else{
                    moveObject(imageObject1:ghost2, x:ghostX, y:ghostY+5)
                }
                
            }
            else if(ghost2PathDirection == GhostDirection.path7){
                if(ghostX >= midC){
                    ghost2PathDirection = GhostDirection.path8
                }
                    
                else{
                    moveObject(imageObject1:ghost2, x:ghostX+5, y:ghostY)
                }
                
            }
            else if(ghost2PathDirection == GhostDirection.path8){
                       if(ghostY <= midR){
                           ghost2PathDirection = GhostDirection.path1
    //                     moveObject(imageObject1:ghost1, x:midC, y:midR)
                       }
                           
                       else{
                           moveObject(imageObject1:ghost2, x:ghostX, y:ghostY-5)
                       }
        
    }
}
@objc func onPlayerTimerFires() {
        
    let pacmanY = Int(pacman1.frame.origin.y);
    

    let pacmanX = Int(pacman1.frame.origin.x);
    
    
    
    for dWall in wallList{
        
    
        
    switch currentDirection {
    case .stop:
        break
        
        
    case .left:
        if((pacmanX-5)>startC){
            // code to go left
            if(pacman1.frame.intersects(dWall.frame)){
                labelScoreBoard.text = "wall l"
                currentDirection = Direction.right
                moveObject(imageObject1:pacman1, x:pacmanX+5, y:pacmanY)
                return
                
            }
            moveObject(imageObject1:pacman1, x:pacmanX-5, y:pacmanY)
            
        }
        break
    case .up:
        if((pacmanY-5)>startR){
            //        code to go up
            if(pacman1.frame.intersects(dWall.frame)){
                labelScoreBoard.text = "wall u"
                currentDirection = Direction.down
                 moveObject(imageObject1:pacman1, x:pacmanX, y:pacmanY+5)
                return
            }
            moveObject(imageObject1:pacman1, x:pacmanX, y:pacmanY-5)
            
        }
        break
    case .down:
        if((pacmanY+5)<endR){
            //        code to go down
            if(pacman1.frame.intersects(dWall.frame)){
                labelScoreBoard.text = "wall d"
                currentDirection = Direction.up
                moveObject(imageObject1:pacman1, x:pacmanX, y:pacmanY-5)
                return
            }
                      moveObject(imageObject1:pacman1, x:pacmanX, y:pacmanY+5)
        }
      break
    case .right:
        if((pacmanX+5)<endC){
            //       code to go right
            if(pacman1.frame.intersects(dWall.frame)){
                labelScoreBoard.text = "wall r"
                currentDirection = Direction.left
                moveObject(imageObject1:pacman1, x:pacmanX-5, y:pacmanY)
                return
            }
                   moveObject(imageObject1:pacman1, x:pacmanX+5, y:pacmanY)
        }
   
    }
        
    }
        
        
        
        
    if(pacman1.frame.intersects(ghost1.frame)) {
        labelScoreBoard.text = "red ghost"
        currentDirection = .stop
  }
    if(pacman1.frame.intersects(ghost2.frame)) {
          labelScoreBoard.text = "green ghost"
        currentDirection = .stop
    }
    for point in pointList{
        if(pacman1.frame.intersects(point.frame)){
//               labelScoreBoard.text = "yellow point"
            score = score+1
            labelScoreBoard.text = String(score)
            point.removeFromSuperview()
            break
        }
    }
}
func movePacman(x:Int, y:Int){
    pacman1.frame = CGRect(x: x, y: y, width: 50, height: 50)
    
}
func moveObject( imageObject1:UIImageView!,  x:Int, y:Int){
    
    imageObject1.frame = CGRect(x: x, y: y, width: 50, height: 50)
    
    
    
    
    
}
}


